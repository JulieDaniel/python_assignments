from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re


app = Flask(__name__)

users_db_connection = MySQLConnector(app,'users')
app.secret_key = 'secret'

@app.route('/')
def email():
    return render_template('index.html', emaillist=users_db_connection.query_db("SELECT * FROM email"))

@app.route('/submit', methods=['POST'])
def submit():
    error = False
    email = request.form['email']
    email_regex = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
    if len(email) < 1:
        flash("Invalid Email Address.")
        error = True
    elif not email_regex.match(email):
        flash("Invalid Email Address!")
        error = True
    else:
        query = "INSERT INTO email (email, created_at) VALUES (:email, NOW())"
        # We'll then create a dictionary of data from the POST data received.
        data = {
            'email': email
        }
        # Run query, with dictionary values injected into the query.
        users_db_connection.query_db(query, data)

        queryresult = users_db_connection.query_db("SELECT * FROM email")
        return render_template('sucess.html', addr=email, emaillist=queryresult)
    return render_template('index.html', emaillist=users_db_connection.query_db("SELECT * FROM email"), error=error)

@app.route('/delete/<int:user_id>')
def delete(user_id):

    query = "DELETE FROM email WHERE id = :emailid"

    data = {
        'emailid': user_id
    }
    # Run query, with dictionary values injected into the query.
    users_db_connection.query_db(query, data)

    queryresult = users_db_connection.query_db("SELECT * FROM email")
    return render_template('index.html', emaillist = queryresult)

if __name__ == '__main__':
    app.run(debug=True)
