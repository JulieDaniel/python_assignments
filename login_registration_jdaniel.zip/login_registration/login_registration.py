from flask import Flask, request, redirect, render_template, session, flash
from flask_bcrypt import Bcrypt

from mysqlconnection import MySQLConnector
import re

app = Flask(__name__)
app.secret_key='secret'
bcrypt = Bcrypt(app)
login_registration_db_connection = MySQLConnector(app,'login_registration')

def invalidEmail(email_str):
    error = False
    email_regex = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
    if len(email_str) < 1:
        flash("Invalid Email Address.")
        error = True
    elif not email_regex.match(email_str):
        flash("Invalid Email Address!")
        error = True
    return(error)

@app.route('/')
def index():

    if 'userid' in session:
        id = session['userid']
    else:
        return(render_template('/login.html'))

    # lookup user name, pass into index.html
    query= "select first_name, last_name from users where id= :id"
    data ={
        'id' :id
    }
    resultlist = login_registration_db_connection.query_db(query, data)
    if len(resultlist)>0:
        resultdict=resultlist[0]
        return render_template('index.html', first_name=resultdict['first_name'], last_name=resultdict['last_name'])

    return (render_template('/login.html'))

@app.route('/register', methods=["POST"])
def registration():

    error = False
    try:
        fname = request.form['first_name']
        lname = request.form['last_name']
        password = request.form['password']
        conf = request.form['password_confirmation']

    except:
        error = True
    # validation
    if (len(fname) < 2):
        flash('That is not a real first name')
        error = True
    if (len(lname) < 2):
        flash('That is not a real last name')
        error = True
    if invalidEmail(request.form['email']):
        flash("Invalid Email Address")
        error = True
    else:
        email = request.form['email']

    if (len(password) < 8):
        flash('Password must be at least 8 characters')
        error = True
    if (conf != password):
        flash('Passwords do not match')
        error = True
    # make sure the user is not already signed up
    query = "select id from users where email= :email"
    data = {
           'email': email
    }
    resultlist = login_registration_db_connection.query_db(query, data)
    if len(resultlist) > 0:
        # user already registered
        flash('Email not unique')
        error=True

    if error:
        return render_template('/registration.html', error=error)


    # run validations and if they are successful we can create the password hash with bcrypt
    pw_hash = bcrypt.generate_password_hash(password)

    insert_query = "INSERT INTO users (first_name, last_name, email, pwdhash, created_at) VALUES (:fname, :lname, :email, :pw_hash, NOW())"
    query_data = {'fname' :fname,
                  'lname' :lname,
                  'email' :email,
                  'pw_hash' :pw_hash}
    login_registration_db_connection.query_db(insert_query, query_data)

    # User is now registered. Automatically log them in.
    query = "select id from users where email =:email and pwdhash = :pw_hash"
    data = {
        'email': email,
        'pw_hash': pw_hash
    }
    resultlist = login_registration_db_connection.query_db(query, data)
    resultdict = resultlist[0]
    session['userid'] = resultdict['id']
    return redirect('/')


@app.route('/login', methods=["POST"])
def login():
    error=False
    if invalidEmail(request.form['email']):
        flash("Invalid Email Address")
        error = True
    else:
        email = request.form['email']
    if len(request.form['password']) > 0:
        password = request.form['password']
    else:
        flash("Must enter password")
        error = True
    if not error:
        query= "select id, pwdhash from users where email =:email"
        data ={
            'email' :email
        }
        resultlist = login_registration_db_connection.query_db(query, data)
        if len(resultlist)>0:
            resultdict=resultlist[0]

            if bcrypt.check_password_hash(resultdict['pwdhash'], password):
                session['userid']=resultdict['id']
                return redirect('/')
            else:
                flash("invalid password")
                errror=True
        else:
            flash("Invalid email")
            error=True


    return render_template('/login.html', error=error)


@app.route('/startreg', methods=["GET"])
def startreg():
    return render_template('/registration.html')


@app.route('/sucess', methods=["POST"])
def sucess():
    return 'sucess'


@app.route('/logout', methods=["post"])
def logout():
    session.clear()
    return redirect('/')



if __name__ == '__main__':
    app.run(debug=True)
