from flask import Flask, render_template, redirect, request, session

app = Flask(__name__)


@app.route('/')
def no_ninjas():
    return render_template('no_ninjas.html')

@app.route('/ninja')
def allfour():
    return render_template('index.html', red=1, blue=1, orange=1, purple=1)

@app.route('/blue')
def blue():
    return render_template('index.html', blue=1)

@app.route('/red')
def red():
    return render_template('index.html', red=1)

@app.route('/orange')
def orange():
    return render_template('index.html', orange=1)

@app.route('/purple')
def purple():
    return render_template('index.html', purple=1)

@app.route('/<path:path>')
def other(path):
    return render_template('index.html', other=1)


if __name__ == '__main__':
    app.run(debug=True)
