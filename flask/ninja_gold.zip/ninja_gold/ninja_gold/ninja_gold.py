from flask import Flask, render_template, request, redirect, session
import random
import datetime

app = Flask(__name__)
app.secret_key = 'ThisIsSecret'

chances={
    'farm':[10, 21],
    'cave':[5,11],
    'house':[2,6],
    'casino':[0,51]
}


@app.route('/')
def index():
    if 'gold' not in session:
        session['gold']=0
    if 'activities' not in session:
        session['activities']=''
    return render_template('index.html', count=session['gold'], activities=session['activities'])

@app.route('/process_money', methods=['POST'])
def process_money():
    building = request.form.get('building')
    if random.randrange(1,101)>50:
        winner=True
    else:
        winner=False
    amount=random.randrange(chances[building][0],chances[building][1])
    if winner:
        session['gold']=session['gold']+ amount
        session['activities']+='<span style=\'color:green;\'>Earned ' + str(amount) + ' golds from the ' + (building)+ '. ('+ str(datetime.datetime.now())+') <br></span>'
    else:
        if session['gold'] < amount:
            amount=session['gold']
        session['gold']=session['gold']-amount
        session['activities']+='<span style=\'color:red;\'>Entered a ' + building + ' and lost ' + str(amount) + '. Ouch! ('+ str(datetime.datetime.now())+') <br></span>'
    return render_template('index.html', count=session['gold'], activities=session['activities'])



@app.route('/reset')
def reset():
    session['gold']=0
    session['activities']=''
    return render_template('index.html', count=session['gold'], activities=session['activities'])



if __name__ == '__main__':
    app.run(debug=True)