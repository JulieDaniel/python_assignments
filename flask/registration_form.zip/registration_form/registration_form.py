from flask import Flask, render_template, request, redirect, request, session, flash
import re

app = Flask(__name__)
app.secret_key = ('secretkey')


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def users():
    error=False
    email = request.form.get('email')
    email_regex = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
    if len(email) < 1:
        flash("Please include email.")
        error = True
    elif not email_regex.match(email):
        flash("Invalid Email Address!")
        error = True

    fname = request.form.get('first_name')
    if len(fname) < 1:
        flash("Please include first name.")
        error = True

    lname = request.form.get('last_name')
    if len(lname) < 1:
        flash("Please include last name.")
        error = True

    if re.search(r'\d', fname) or re.search(r'\d', lname):
        error=True
        flash("Name cannot contain a number.")

    password_regex = re.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$")
    password = request.form.get('password')
    if (len(password) < 8) or not password_regex.match(password):
        flash('Password must include 1 number and 1 uppercase letter.')
        error=True
    password2 = request.form.get('confirm_password')
    if password2 != password:
        flash("Passwords are not the same.")
        error=True

    if not error:
        flash ("Good Job!")
    print("email: ", email)
    print("fname: ", fname)
    print("lname: ", lname)
    print("pwd : ", "\'" + password + "\'")
    print("conf: ", "\'" + password2 + "\'")

    return redirect('/')

if __name__ == '__main__':
    app.run()
