from flask import Flask, render_template, request, redirect, session
import random

app = Flask(__name__)
app.secret_key = 'ThisIsSecret'



@app.route('/')
def index():
    if 'number' not in session:
        session['number']= random.randrange(1,101)
    return render_template('index.html')



@app.route('/again')
def playagain():
    # reset to new number
    session['number'] = random.randrange(1, 101)
    return render_template('index.html')



@app.route('/submit', methods=['POST'])
def handleguess():
    try:
        guess = int(request.form.get('guess'))
        number = session['number']
        if (number < guess):
            return render_template('index.html',vishigh=1)
        if (number > guess):
            return render_template('index.html', vislow=1)
        return render_template('index.html', visright=guess)
    except:
        render_template('index.html')
        




if __name__ == '__main__':
    app.run(debug=True)
