from flask import Flask, render_template, request, redirect

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/users', methods=['POST'])
def users():
   print "Got Post Info"


   name = request.form.get('name')
   location = request.form.get('location')
   language = request.form.get('language')
   comment = request.form.get('comment')
   print(name, location, language, comment)

   return render_template('works.html',name=name, location=location, language=language, comment=comment)

if __name__ == '__main__':
    app.run(debug=True)
