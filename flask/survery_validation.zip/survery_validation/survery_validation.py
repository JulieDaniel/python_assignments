from flask import Flask, render_template, request, redirect, request, session, flash

app = Flask(__name__)
app.secret_key = ('secretkey')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/users', methods=['POST'])
def users():
   print "Got Post Info"
   error=False


   name = request.form.get('name')
   if len(request.form['name']) < 1:
       flash("Name cannot be empty!")
       error=True

   location = request.form.get('location')
   language = request.form.get('language')
   comment = request.form.get('comment')
   if len(request.form ['comment'])<1:
       flash('Comment needed.')
       error=True
   if len(request.form['comment'])>120:
       flash("Make comment shorter.")
       error=True

   print(name, location, language, comment)
   if error:
    return redirect('/')

   return render_template('works.html',name=name, location=location, language=language, comment=comment)



if __name__ == '__main__':
    app.run(debug=True)
