from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = 'ThisIsSecret'



@app.route('/')
def index():
  if 'counter' in session:
    session['counter']=session['counter']+1
  else:
    session['counter']=1
  return render_template('index.html', count=session['counter'])



@app.route('/plustwo')
def plustwo():
    if 'counter' in session:
        session['counter'] = session['counter'] + 2
    else:
        session['counter'] = 2
    return render_template('index.html', count=session['counter'])


@app.route('/reset')
def reset():
    session['counter'] =1
    return render_template('index.html', count=session['counter'])


if __name__ == '__main__':
    app.run(debug=True)
