from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re

app = Flask(__name__)

friends_db_connection = MySQLConnector(app,'friends')
app.secret_key='secret'


@app.route('/')
def index():
    resultlist = friends_db_connection.query_db("SELECT * FROM friends")
    return render_template('index.html', friendlist=resultlist )

@app.route('/friends', methods=["POST"])
def create():
    error = False
    try:
        email = request.form['email']
        first = request.form['first_name']
        last = request.form['last_name']
    except:
        flash("You must submit email, first, and last")
        error = True

    if not error:
        #validate email
        email_regex = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
        if len(email) < 1:
            flash("Invalid Email Address.")
            error = True
        elif not email_regex.match(email):
            flash("Invalid Email Address!")
            error = True
        else:
            #insert email with name
            query = "INSERT INTO friends (first_name, last_name, email, created_at) VALUES (:fname, :lname, :email, NOW())"
            # We'll then create a dictionary of data from the POST data received.
            data = {
                'email': email,
                'fname': first,
                'lname': last
            }
            # Run query, with dictionary values injected into the query.
            friends_db_connection.query_db(query, data)

            return redirect('/')

    return render_template('index.html', friendlist=friends_db_connection.query_db("SELECT * FROM friends"), error=error)


@app.route('/friends/<id>/edit', methods=['POST'])
def edit(id):

    query = "SELECT * FROM friends WHERE id = :friendsid"

    data = {
        'friendsid': id
    }

    resultlist = friends_db_connection.query_db(query, data)

    return render_template('/edit.html', friend=resultlist[0])


@app.route('/friends/<id>', methods=["POST"])
def update(id):
    email = request.form['email']
    first = request.form['first_name']
    last = request.form['last_name']

    query = "UPDATE friends set first_name= :fname, last_name= :lname, email= :email where id=:friendsid"

    data = {
        'email': email,
        'fname': first,
        'lname': last,
        'friendsid': id
    }
    friends_db_connection.query_db(query, data)
    return redirect('/')


@app.route('/friends/<id>/delete', methods=["POST"])
def destroy(id):
    query = "DELETE FROM friends WHERE id = :friendsid"

    data = {
        'friendsid': id
    }
    # Run query, with dictionary values injected into the query.
    friends_db_connection.query_db(query, data)

    queryresult = friends_db_connection.query_db("SELECT * FROM friends")
    return render_template('index.html', friendlist=queryresult)



if __name__ == '__main__':
    app.run(debug=True)
