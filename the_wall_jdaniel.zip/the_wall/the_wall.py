from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re
from flask_bcrypt import Bcrypt


app = Flask(__name__)

users_db_connection = MySQLConnector(app,'wall')
bcrypt = Bcrypt(app)
app.secret_key = 'secret'

def invalidEmail(email_str):
    error = False
    email_regex = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
    if len(email_str) < 1:
        flash("Invalid Email Address")
        error = True
    elif not email_regex.match(email_str):
        flash("Invalid Email Address")
        error = True
    return(error)



@app.route('/')
def mainpage():

    if 'userid' in session:
        id = session['userid']
    else:
        return(render_template('/login.html'))

    # lookup user name, pass into index.html
    query= "select first_name, last_name from users where id= :id"
    data ={
        'id' :id
    }
    resultlist = users_db_connection.query_db(query, data)
    # if the user's id was found in the users table
    if len(resultlist)>0:
        # set vairiable for webpage header
        resultdict=resultlist[0]
        first_name=resultdict['first_name']
    else:
        # somethings wrong, the user id is set in the cookie, but not found in db, force login/reg
        session.clear()
        return(render_template('/login.html'))


    query="select users.first_name as first, users.last_name as last, messages.message, messages.id as msgid, DATE_FORMAT(messages.created_at, \"%M %D %Y\")as date from users, messages where users.id = messages.user_id order by messages.created_at desc"
    messagelist = users_db_connection.query_db(query)
    for message in messagelist:
        query= "SELECT comments.comment, users.first_name as first, users.last_name as last, DATE_FORMAT(comments.created_at, \"%M %D %Y\")as date FROM wall.comments, wall.users where (comments.message_id = :id) and (users.id = comments.user_id) order by comments.created_at"
        data = {
            'id': message['msgid']
        }
        commentlist = users_db_connection.query_db(query, data)
        message['comments'] = commentlist
    return render_template('index.html', first=first_name, messagelist=messagelist)



@app.route('/register', methods=["POST"])
def registration():

    error = False
    try:
        fname = request.form['first_name']
        lname = request.form['last_name']
        password = request.form['password']
        conf = request.form['password_confirmation']

    except:
        error = True
    # validation
    if (len(fname) < 2):
        flash('Must enter first name')
        error = True
    if (len(lname) < 2):
        flash('Must enter last name')
        error = True
    if invalidEmail(request.form['email']):
        flash("Invalid Email Address")
        error = True
    else:
        email = request.form['email']

    if (len(password) < 8):
        flash('Password must be at least 8 characters')
        error = True
    if (conf != password):
        flash('Passwords do not match')
        error = True
    if not error:
        # make sure the user is not already signed up
        query = "select id from users where email= :email"
        data = {
               'email': email
        }
        resultlist = users_db_connection.query_db(query, data)
        if len(resultlist) > 0:
            # user already registered
            flash('Email not unique')
            error=True

    if error:
        return render_template('/registration.html', error=error)


    # run validations and if they are successful we can create the password hash with bcrypt
    pw_hash = bcrypt.generate_password_hash(password)

    insert_query = "INSERT INTO users (first_name, last_name, email, password, created_at) VALUES (:fname, :lname, :email, :pw_hash, NOW())"
    query_data = {'fname' :fname,
                  'lname' :lname,
                  'email' :email,
                  'pw_hash' :pw_hash}
    users_db_connection.query_db(insert_query, query_data)

    # User is now registered. Automatically log them in.
    query = "select id from users where email =:email and password = :pw_hash"
    data = {
        'email': email,
        'pw_hash': pw_hash
    }
    resultlist = users_db_connection.query_db(query, data)
    resultdict = resultlist[0]
    session['userid'] = resultdict['id']
    return redirect('/')


@app.route('/login', methods=["POST"])
def login():
    error=False
    if invalidEmail(request.form['email']):
        flash("Invalid Email Address")
        error = True
    else:
        email = request.form['email']
    if len(request.form['password']) > 0:
        password = request.form['password']
    else:
        flash("Must enter password")
        error = True
    if not error:
        query= "select id, password from users where email =:email"
        data ={
            'email' :email
        }
        resultlist = users_db_connection.query_db(query, data)
        if len(resultlist)>0:
            resultdict=resultlist[0]

            if bcrypt.check_password_hash(resultdict['password'], password):
                session['userid']=resultdict['id']
                return redirect('/')
            else:
                flash("invalid password")
                errror=True
        else:
            flash("Invalid email")
            error=True


    return render_template('/login.html', error=error)


@app.route('/startreg', methods=["GET"])
def startreg():
    return render_template('/registration.html')

@app.route('/logout', methods=["post"])
def logout():
    session.clear()
    return redirect('/')

@app.route('/post', methods=["post"])
def post():
    id = session['userid']
    message = request.form['newpost']
    query="insert into messages (user_id, message, created_at, updated_at) values (:user_id, :message, NOW(), NOW())"
    data = {
        'user_id' :id,
        'message' :message
    }
    users_db_connection.query_db(query, data)
    return redirect('/')

@app.route('/post/<msgid>', methods=["POST"])
def update(msgid):
    userid = session['userid']
    comment = request.form['newcomment']
    query = "insert into comments (user_id, message_id, comment, created_at, updated_at) values (:user_id, :message_id, :comment, NOW(), NOW())"
    data = {
        'user_id': userid,
        'comment': comment,
        'message_id': msgid
    }
    users_db_connection.query_db(query, data)
    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)
